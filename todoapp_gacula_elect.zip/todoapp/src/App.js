import React from 'react';
import './App.css';

import TodoList from './Cmponents/TodoList';


function App() {
  return (
    <>
    <div className="To-DoApp">
    <TodoList />
    </div>
    

    
    
    <div className='iconsagedli'></div>
    </>
    
 
  )
}

export default App;
