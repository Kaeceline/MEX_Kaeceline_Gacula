import React, {useState} from 'react';

function LoginForm({Login, error}) {
    const [details, setDetails] = useState({username: "", password: ""})
    const submitHandler = e => {
        e.preventDefault();
        Login(details);
    }
  return (
    <div> 
        <form  onSubmit={submitHandler}>
            <div className='form-inner'>
            <h2>TO-DO Login</h2>
              <div className='form'>

              
              <div className='form-group'>           
                    <input type='text' name='username' id='username' placeholder='Username'
                    onChange={e=> setDetails({...details,username:e.target.value})} value={details.username}/>
                   </div>
                   

                   <div className='form-group'>
                    
                    <input type='password' name='password' id='password' placeholder='Password'
                    onChange={e=> setDetails({...details,password:e.target.value})} value={details.password}/>

                   </div>
                   
                     <input type='submit' className='btnlogin' value='LOGIN'></input>
                   
              </div>
            </div>
        </form>
    </div>
  )
}

export default LoginForm;