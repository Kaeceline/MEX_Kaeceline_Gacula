import React from 'react'

export default function TodoList(props) {
    const { todo, removeTodo, completeTodo, importantTodo } = props
    return (
        <div className={todo.completed ? "todo-row complete" : "todo-row"} style={todo.important ? { background: "rgb(198, 54, 54)" } : { background: "rgb(65, 183, 88, 0.8)"}}>
            {todo.text}
            <div className="iconsContainer">
                <button onClick={() => importantTodo(todo.id)}>Priority</button> | 
                <button onClick={() => completeTodo(todo.id)}>Task Done</button> |
                <button onClick={() => removeTodo(todo.id)}>Delete Task</button>
            </div>
        </div>
    )
}